"use strict";
(() => {
var exports = {};
exports.id = 186;
exports.ids = [186];
exports.modules = {

/***/ 717:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ SSG),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function SSG() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "a-full"
    });
}
async function getStaticPaths(context) {
    let data = [];
    await fetch("https://jsonplaceholder.typicode.com/posts").then((response)=>response.json()).then((response)=>{
        data = response;
    });
    let paths = [];
    if (Array.isArray(data) && data.length > 0) {
        paths = data.map((post)=>({
                params: {
                    ssg: `${post.id.toString()}`
                }
            }));
    }
    return {
        paths,
        fallback: false
    };
}
async function getStaticProps(context) {
    let data = [];
    await fetch("https://jsonplaceholder.typicode.com/posts").then((response)=>response.json()).then((response)=>{
        data = response;
    });
    return {
        props: {
            data
        }
    };
}


/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(717));
module.exports = __webpack_exports__;

})();