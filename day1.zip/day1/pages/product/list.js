export default function productList() {
  return <div>productList</div>;
}
