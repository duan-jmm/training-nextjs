import "@/src/assets/sass/main.scss";
import "@/src/assets/sass/styles.css";

export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />;
}
