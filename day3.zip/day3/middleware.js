import { NextResponse } from "next/server";

export async function middleware(req) {
  // const token = await getToken({
  //   req,
  //   secret: process.env.NEXTAUTH_SECRET,
  //   secureCookie: false,
  // });

  // if (req.nextUrl.pathName.startsWith("/dashboard") && !token) {
  //   return NextResponse.redirect("/auth");
  // }

  return NextResponse.next();
}
