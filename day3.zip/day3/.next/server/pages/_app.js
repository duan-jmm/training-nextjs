/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _src_assets_sass_main_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/src/assets/sass/main.scss */ \"./src/assets/sass/main.scss\");\n/* harmony import */ var _src_assets_sass_main_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_src_assets_sass_main_scss__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _src_components_product_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/src/components/product.layout */ \"./src/components/product.layout.js\");\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next-auth/react */ \"next-auth/react\");\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_4__);\n\n\n\n\n\nfunction AppSwitchTheme({ children  }) {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    if (router.asPath.startsWith(`/product`)) {\n        return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_components_product_layout__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n            children: children\n        }, void 0, false, {\n            fileName: \"D:\\\\2. NextJS Training\\\\day3\\\\pages\\\\_app.js\",\n            lineNumber: 10,\n            columnNumber: 7\n        }, this);\n    } else {\n        return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n            children: children\n        }, void 0, false);\n    }\n}\nfunction App(props) {\n    let { Component , pageProps: { session , ...pageProps }  } = props;\n    console.log(session, \"SESSION\");\n    console.log(props, \"PROPS\");\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_auth_react__WEBPACK_IMPORTED_MODULE_4__.SessionProvider, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(AppSwitchTheme, {\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"D:\\\\2. NextJS Training\\\\day3\\\\pages\\\\_app.js\",\n                lineNumber: 33,\n                columnNumber: 9\n            }, this)\n        }, void 0, false, {\n            fileName: \"D:\\\\2. NextJS Training\\\\day3\\\\pages\\\\_app.js\",\n            lineNumber: 32,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"D:\\\\2. NextJS Training\\\\day3\\\\pages\\\\_app.js\",\n        lineNumber: 31,\n        columnNumber: 5\n    }, this);\n}\nApp.getInitialProps = async ({ Component , ctx  })=>{\n    let pageProps = Component.getInitialProps ? await Component.getInitialProps(ctx) : {};\n    return {\n        pageProps: {\n            session: await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_4__.getSession)(ctx),\n            ...pageProps\n        }\n    };\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (App);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQW9DO0FBQ0c7QUFDb0I7QUFDQTtBQUUzRCxTQUFTSSxlQUFlLEVBQUNDLFNBQVEsRUFBQyxFQUFFO0lBQ2xDLE1BQU1DLFNBQVNOLHNEQUFTQTtJQUN4QixJQUFJTSxPQUFPQyxNQUFNLENBQUNDLFVBQVUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFFO1FBQ3ZDLHFCQUNFLDhEQUFDUCxzRUFBYUE7c0JBQ1hJOzs7Ozs7SUFHUCxPQUFPO1FBQ0wscUJBQ0U7c0JBQ0dBOztJQUdQLENBQUM7QUFDSDtBQUVBLFNBQVNJLElBQUlDLEtBQUssRUFBRTtJQUNsQixJQUFJLEVBQ0ZDLFVBQVMsRUFDVEMsV0FBVyxFQUFFQyxRQUFPLEVBQUUsR0FBR0QsV0FBVyxHQUNyQyxHQUFHRjtJQUNKSSxRQUFRQyxHQUFHLENBQUNGLFNBQVM7SUFDckJDLFFBQVFDLEdBQUcsQ0FBQ0wsT0FBTztJQUNuQixxQkFDRSw4REFBQ1IsNERBQWVBO2tCQUNkLDRFQUFDRTtzQkFDQyw0RUFBQ087Z0JBQVcsR0FBR0MsU0FBUzs7Ozs7Ozs7Ozs7Ozs7OztBQUloQztBQUVBSCxJQUFJTyxlQUFlLEdBQUcsT0FBTyxFQUFDTCxVQUFTLEVBQUNNLElBQUcsRUFBQyxHQUFLO0lBQy9DLElBQUlMLFlBQVlELFVBQVVLLGVBQWUsR0FDdkMsTUFBTUwsVUFBVUssZUFBZSxDQUFDQyxPQUFPLENBQUMsQ0FBQztJQUMzQyxPQUFPO1FBQ0xMLFdBQVc7WUFDVEMsU0FBUyxNQUFNViwyREFBVUEsQ0FBQ2M7WUFDMUIsR0FBR0wsU0FBUztRQUNkO0lBQ0Y7QUFDRjtBQUVBLGlFQUFlSCxHQUFHQSxFQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZGF5MS8uL3BhZ2VzL19hcHAuanM/ZTBhZCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgJ0Avc3JjL2Fzc2V0cy9zYXNzL21haW4uc2NzcydcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJ1xuaW1wb3J0IFByb2R1Y3RMYXlvdXQgZnJvbSAnQC9zcmMvY29tcG9uZW50cy9wcm9kdWN0LmxheW91dCdcbmltcG9ydCB7U2Vzc2lvblByb3ZpZGVyLCBnZXRTZXNzaW9ufSBmcm9tICduZXh0LWF1dGgvcmVhY3QnXG5cbmZ1bmN0aW9uIEFwcFN3aXRjaFRoZW1lKHtjaGlsZHJlbn0pIHtcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKClcbiAgaWYgKHJvdXRlci5hc1BhdGguc3RhcnRzV2l0aChgL3Byb2R1Y3RgKSl7XG4gICAgcmV0dXJuIChcbiAgICAgIDxQcm9kdWN0TGF5b3V0PlxuICAgICAgICB7Y2hpbGRyZW59XG4gICAgICA8L1Byb2R1Y3RMYXlvdXQ+XG4gICAgKVxuICB9IGVsc2Uge1xuICAgIHJldHVybiAoXG4gICAgICA8PlxuICAgICAgICB7Y2hpbGRyZW59XG4gICAgICA8Lz5cbiAgICApXG4gIH1cbn1cblxuZnVuY3Rpb24gQXBwKHByb3BzKSB7XG4gIGxldCB7XG4gICAgQ29tcG9uZW50LFxuICAgIHBhZ2VQcm9wczogeyBzZXNzaW9uLCAuLi5wYWdlUHJvcHMgfSxcbiAgfSA9IHByb3BzXG4gIGNvbnNvbGUubG9nKHNlc3Npb24sICdTRVNTSU9OJylcbiAgY29uc29sZS5sb2cocHJvcHMsICdQUk9QUycpXG4gIHJldHVybiAoXG4gICAgPFNlc3Npb25Qcm92aWRlcj5cbiAgICAgIDxBcHBTd2l0Y2hUaGVtZT5cbiAgICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxuICAgICAgPC9BcHBTd2l0Y2hUaGVtZT5cbiAgICA8L1Nlc3Npb25Qcm92aWRlcj5cbiAgKVxufVxuXG5BcHAuZ2V0SW5pdGlhbFByb3BzID0gYXN5bmMgKHtDb21wb25lbnQsY3R4fSkgPT4ge1xuICBsZXQgcGFnZVByb3BzID0gQ29tcG9uZW50LmdldEluaXRpYWxQcm9wcyA/XG4gICAgYXdhaXQgQ29tcG9uZW50LmdldEluaXRpYWxQcm9wcyhjdHgpIDoge31cbiAgcmV0dXJuIHtcbiAgICBwYWdlUHJvcHM6IHtcbiAgICAgIHNlc3Npb246IGF3YWl0IGdldFNlc3Npb24oY3R4KSxcbiAgICAgIC4uLnBhZ2VQcm9wc1xuICAgIH1cbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBBcHAiXSwibmFtZXMiOlsidXNlUm91dGVyIiwiUHJvZHVjdExheW91dCIsIlNlc3Npb25Qcm92aWRlciIsImdldFNlc3Npb24iLCJBcHBTd2l0Y2hUaGVtZSIsImNoaWxkcmVuIiwicm91dGVyIiwiYXNQYXRoIiwic3RhcnRzV2l0aCIsIkFwcCIsInByb3BzIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwic2Vzc2lvbiIsImNvbnNvbGUiLCJsb2ciLCJnZXRJbml0aWFsUHJvcHMiLCJjdHgiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./src/components/product.layout.js":
/*!******************************************!*\
  !*** ./src/components/product.layout.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction ProductLayout(props) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"w-full\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"w-full h-20 bg-white border-b\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                    children: \" Product Layout \"\n                }, void 0, false, {\n                    fileName: \"D:\\\\2. NextJS Training\\\\day3\\\\src\\\\components\\\\product.layout.js\",\n                    lineNumber: 5,\n                    columnNumber: 17\n                }, this)\n            }, void 0, false, {\n                fileName: \"D:\\\\2. NextJS Training\\\\day3\\\\src\\\\components\\\\product.layout.js\",\n                lineNumber: 4,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: `w-full bg-gray-100`,\n                children: props?.children\n            }, void 0, false, {\n                fileName: \"D:\\\\2. NextJS Training\\\\day3\\\\src\\\\components\\\\product.layout.js\",\n                lineNumber: 7,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\2. NextJS Training\\\\day3\\\\src\\\\components\\\\product.layout.js\",\n        lineNumber: 3,\n        columnNumber: 9\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductLayout);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9wcm9kdWN0LmxheW91dC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUEsU0FBU0EsY0FBY0MsS0FBSyxFQUFDO0lBQ3pCLHFCQUNJLDhEQUFDQztRQUFJQyxXQUFVOzswQkFDWCw4REFBQ0Q7Z0JBQUlDLFdBQVc7MEJBQ1osNEVBQUNDOzhCQUFFOzs7Ozs7Ozs7OzswQkFFUCw4REFBQ0Y7Z0JBQUlDLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQzswQkFDL0JGLE9BQU9JOzs7Ozs7Ozs7Ozs7QUFJeEI7QUFFQSxpRUFBZUwsYUFBYUEsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2RheTEvLi9zcmMvY29tcG9uZW50cy9wcm9kdWN0LmxheW91dC5qcz9mMTQ1Il0sInNvdXJjZXNDb250ZW50IjpbImZ1bmN0aW9uIFByb2R1Y3RMYXlvdXQocHJvcHMpe1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17J3ctZnVsbCBoLTIwIGJnLXdoaXRlIGJvcmRlci1iJ30+XHJcbiAgICAgICAgICAgICAgICA8cD4gUHJvZHVjdCBMYXlvdXQgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LWZ1bGwgYmctZ3JheS0xMDBgfT5cclxuICAgICAgICAgICAgICAgIHtwcm9wcz8uY2hpbGRyZW59XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQcm9kdWN0TGF5b3V0OyJdLCJuYW1lcyI6WyJQcm9kdWN0TGF5b3V0IiwicHJvcHMiLCJkaXYiLCJjbGFzc05hbWUiLCJwIiwiY2hpbGRyZW4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/product.layout.js\n");

/***/ }),

/***/ "./src/assets/sass/main.scss":
/*!***********************************!*\
  !*** ./src/assets/sass/main.scss ***!
  \***********************************/
/***/ (() => {



/***/ }),

/***/ "next-auth/react":
/*!**********************************!*\
  !*** external "next-auth/react" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();