/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _src_assets_sass_main_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/src/assets/sass/main.scss */ \"./src/assets/sass/main.scss\");\n/* harmony import */ var _src_assets_sass_main_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_src_assets_sass_main_scss__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _src_assets_sass_styles_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/src/assets/sass/styles.css */ \"./src/assets/sass/styles.css\");\n/* harmony import */ var _src_assets_sass_styles_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_src_assets_sass_styles_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _src_components_product_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/src/components/product.layout */ \"./src/components/product.layout.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);\n\n\n\n\n\n// function appSwitchTheme({ children }) {\n//   const router = useRouter();\n//   if (router.asPath.startsWith(\"/product\")) {\n//     return <ProductLayout>{children}</ProductLayout>;\n//   } else {\n//     return children;\n//   }\n// }\nfunction App({ Component , pageProps  }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n        ...pageProps\n    }, void 0, false, {\n        fileName: \"D:\\\\2. NextJS Training\\\\day2\\\\pages\\\\_app.js\",\n        lineNumber: 16,\n        columnNumber: 10\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQXFDO0FBQ0M7QUFDc0I7QUFDcEI7QUFFeEMsMENBQTBDO0FBQzFDLGdDQUFnQztBQUNoQyxnREFBZ0Q7QUFDaEQsd0RBQXdEO0FBQ3hELGFBQWE7QUFDYix1QkFBdUI7QUFDdkIsTUFBTTtBQUNOLElBQUk7QUFFVyxTQUFTRSxJQUFJLEVBQUVDLFVBQVMsRUFBRUMsVUFBUyxFQUFFLEVBQUU7SUFDcEQscUJBQU8sOERBQUNEO1FBQVcsR0FBR0MsU0FBUzs7Ozs7O0FBQ2pDLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9kYXkxLy4vcGFnZXMvX2FwcC5qcz9lMGFkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIkAvc3JjL2Fzc2V0cy9zYXNzL21haW4uc2Nzc1wiO1xuaW1wb3J0IFwiQC9zcmMvYXNzZXRzL3Nhc3Mvc3R5bGVzLmNzc1wiO1xuaW1wb3J0IFByb2R1Y3RMYXlvdXQgZnJvbSBcIkAvc3JjL2NvbXBvbmVudHMvcHJvZHVjdC5sYXlvdXRcIjtcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xuXG4vLyBmdW5jdGlvbiBhcHBTd2l0Y2hUaGVtZSh7IGNoaWxkcmVuIH0pIHtcbi8vICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG4vLyAgIGlmIChyb3V0ZXIuYXNQYXRoLnN0YXJ0c1dpdGgoXCIvcHJvZHVjdFwiKSkge1xuLy8gICAgIHJldHVybiA8UHJvZHVjdExheW91dD57Y2hpbGRyZW59PC9Qcm9kdWN0TGF5b3V0Pjtcbi8vICAgfSBlbHNlIHtcbi8vICAgICByZXR1cm4gY2hpbGRyZW47XG4vLyAgIH1cbi8vIH1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICByZXR1cm4gPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPjtcbn1cbiJdLCJuYW1lcyI6WyJQcm9kdWN0TGF5b3V0IiwidXNlUm91dGVyIiwiQXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./src/components/product.layout.js":
/*!******************************************!*\
  !*** ./src/components/product.layout.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction ProductLayout(props) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"w-full\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"w-full bg-white h-20 border-b\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                    children: \"Product Layout\"\n                }, void 0, false, {\n                    fileName: \"D:\\\\2. NextJS Training\\\\day2\\\\src\\\\components\\\\product.layout.js\",\n                    lineNumber: 5,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"D:\\\\2. NextJS Training\\\\day2\\\\src\\\\components\\\\product.layout.js\",\n                lineNumber: 4,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                className: \"w-full bg-gray-100\",\n                children: props?.children\n            }, void 0, false, {\n                fileName: \"D:\\\\2. NextJS Training\\\\day2\\\\src\\\\components\\\\product.layout.js\",\n                lineNumber: 7,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\2. NextJS Training\\\\day2\\\\src\\\\components\\\\product.layout.js\",\n        lineNumber: 3,\n        columnNumber: 5\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductLayout);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9wcm9kdWN0LmxheW91dC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUEsU0FBU0EsY0FBY0MsS0FBSyxFQUFFO0lBQzVCLHFCQUNFLDhEQUFDQztRQUFJQyxXQUFVOzswQkFDYiw4REFBQ0Q7Z0JBQUlDLFdBQVU7MEJBQ2IsNEVBQUNDOzhCQUFFOzs7Ozs7Ozs7OzswQkFFTCw4REFBQ0Y7Z0JBQUlDLFdBQVU7MEJBQXNCRixPQUFPSTs7Ozs7Ozs7Ozs7O0FBR2xEO0FBRUEsaUVBQWVMLGFBQWFBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9kYXkxLy4vc3JjL2NvbXBvbmVudHMvcHJvZHVjdC5sYXlvdXQuanM/ZjE0NSJdLCJzb3VyY2VzQ29udGVudCI6WyJmdW5jdGlvbiBQcm9kdWN0TGF5b3V0KHByb3BzKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXdoaXRlIGgtMjAgYm9yZGVyLWJcIj5cclxuICAgICAgICA8cD5Qcm9kdWN0IExheW91dDwvcD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLWdyYXktMTAwXCI+e3Byb3BzPy5jaGlsZHJlbn08L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFByb2R1Y3RMYXlvdXQ7XHJcbiJdLCJuYW1lcyI6WyJQcm9kdWN0TGF5b3V0IiwicHJvcHMiLCJkaXYiLCJjbGFzc05hbWUiLCJwIiwiY2hpbGRyZW4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/product.layout.js\n");

/***/ }),

/***/ "./src/assets/sass/main.scss":
/*!***********************************!*\
  !*** ./src/assets/sass/main.scss ***!
  \***********************************/
/***/ (() => {



/***/ }),

/***/ "./src/assets/sass/styles.css":
/*!************************************!*\
  !*** ./src/assets/sass/styles.css ***!
  \************************************/
/***/ (() => {



/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();