import "@/src/assets/sass/main.scss";
import "@/src/assets/sass/styles.css";
import ProductLayout from "@/src/components/product.layout";
import { useRouter } from "next/router";

// function appSwitchTheme({ children }) {
//   const router = useRouter();
//   if (router.asPath.startsWith("/product")) {
//     return <ProductLayout>{children}</ProductLayout>;
//   } else {
//     return children;
//   }
// }

export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />;
}
