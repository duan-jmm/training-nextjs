import axios from "axios";

export default function ProductSsr(props) {
  return <div className="w-full"></div>;
}

export async function getServerSideProps(context) {
  const [err, data] = await axios
    .get(`http://localhost:3000/api/product`, {})
    .then((Response) => {
      return [null, Response.data];
    })
    .catch((err) => {
      return [err, null];
    });

  if (err) {
    return {
      redirect: {
        destination: "/home",
        permanent: false,
      },
    };
  } else {
    return {
      props: { data },
    };
  }
}
