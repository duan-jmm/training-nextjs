module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
    "postcss-plugin": {},
  },
};
